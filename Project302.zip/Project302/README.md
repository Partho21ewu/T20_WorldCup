# IPL-Indian-Premier-League-cricket-dbms-mini-project
First download and install the xampp server.
Open the xampp control panel and then start apache server and mysql in it.
Then click on the mysql' admin in xampp.
then copy this file into C:\xampp\htdocs this location.
After that click on mysql's admin then create a database name as "cricket"  
Then goto import section in browser
Importmport cricket.sql file from this downloaded file.
Then to start project enter in chrome or in any browser as below

http://localhost/thecricket/index.html 

Then use these passwords for authentication
For admin:- 
Admin id: "admin" password : "123"
For user:- 
User id: "user" password: "123" then login
